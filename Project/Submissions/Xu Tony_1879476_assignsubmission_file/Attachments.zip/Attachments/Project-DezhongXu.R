library(dplyr)
library(caret)
library(glmnet)
library(VGAM)
library(ggplot2)
library(rpart)
library(rpart.plot)
library(caret)
library(randomForest)
library(sparseSVM)
library(e1071)

#1.0 Data Preparation
raw<- read.csv('./traffic_accidents.csv')
df<- read.csv('./traffic_accidents.csv')

#1.1 Data Screening and Variable Selection
df<- df %>% filter(trafficway_type == 'FOUR WAY' | 
                        trafficway_type == 'T-INTERSECTION' | 
                        trafficway_type == 'L-INTERSECTION' | 
                        trafficway_type == 'Y-INTERSECTION' | 
                        trafficway_type == 'ROUNDABOUT')

df <- df[c('crash_hour','crash_day_of_week','crash_month','traffic_control_device',
           'weather_condition','lighting_condition','first_crash_type','alignment',
           'roadway_surface_cond','road_defect','most_severe_injury')]

df[] <- lapply(df, function(x) {
  if (is.character(x)) factor(x) else x
})


#1.2 Data Cleaning 
df_sum <- lapply(df, function(x) {
  if (is.factor(x)) {
    list(summary = summary(x), levels = levels(x))
  } else {
    summary(x)
  }
})


min_ratio <- 0.01  # 1% threshold
df_clean <- df
total_n <- nrow(df_clean)

# Identify target column (assumed to be the last column)
target_col <- names(df_clean)[ncol(df_clean)]

# Get all factor/character columns, excluding the target column
qual_cols <- names(Filter(function(x) is.factor(x) || is.character(x), df_clean))
qual_cols <- setdiff(qual_cols, target_col)

# Ensure all relevant columns are factors
df_clean[qual_cols] <- lapply(df_clean[qual_cols], function(col) {
  if (is.character(col)) factor(col) else col
})

# Identify low-frequency levels to filter out
bad_level_map <- lapply(df_clean[qual_cols], function(col) {
  level_counts <- table(col)
  threshold <- ceiling(min_ratio * total_n)
  bad_levels <- names(level_counts[level_counts < threshold])
  bad_levels <- union(bad_levels, "UNKNOWN")  # Also drop "UNKNOWN"
  return(bad_levels)
})

# Filter out rows with low-frequency levels
for (col_name in names(bad_level_map)) {
  bad_levels <- bad_level_map[[col_name]]
  df_clean <- df_clean[!df_clean[[col_name]] %in% bad_levels, ]
}

# Filter out rows with target level "REPORTED, NOT EVIDENT"
df_clean <- df_clean[df_clean[[target_col]] != "REPORTED, NOT EVIDENT", ]

# Drop unused factor levels
df_clean[qual_cols] <- lapply(df_clean[qual_cols], droplevels)
df_clean[[target_col]] <- droplevels(df_clean[[target_col]])

# Summary
df_clean_sum <- lapply(df_clean, function(x) {
  if (is.factor(x)) {
    list(summary = summary(x), levels = levels(x))
  } else {
    summary(x)
  }
})

#---Data Transformation---

df_clean$crash_hour <- with(df_clean, ifelse(crash_hour >= 7 & crash_hour <= 9, "AM Peak",
                                 ifelse(crash_hour >= 16 & crash_hour <= 18, "PM Peak",
                                        ifelse(crash_hour >= 6 & crash_hour <= 21, "Off-Peak", "Night"))))
df_clean$crash_hour <- factor(df_clean$crash_hour, levels = c("AM Peak", "PM Peak", "Off-Peak", "Night"))

df_clean$crash_day_of_week <- with(df_clean, ifelse(crash_day_of_week >= 1 & crash_day_of_week <= 5, "Weekday", "Weekend"))
df_clean$crash_day_of_week <- factor(df_clean$crash_day_of_week, levels = c('Weekday','Weekend'))

df_clean <- df_clean[, !(names(df_clean) %in% c("alignment", "road_defect"))]
write.csv(df_clean, file ='./Cleaned Traffic Accident Data.csv',row.names = FALSE)


#2. Split data to train and test set
set.seed(614)

train_index <- createDataPartition(df_clean$most_severe_injury, p = 0.8, list = FALSE)

df_train <- df_clean[train_index,]
df_test <-df_clean[-train_index,]


#3. Training Model
# --- 3.1 --- KNN ---
k_grid <- expand.grid(k = seq(1, 51, by = 4))

ctrl <- trainControl(method = "cv", number = 10)

knn_model <- train(
  most_severe_injury ~ .,
  data = df_train,
  method = "knn",
  trControl = ctrl,
  preProcess = c("center", "scale"),
  tuneGrid = k_grid 
)

knn_model$results #show results
knn_model$bestTune #best tune



# ---3.2 --- LASSO
set.seed(614)

x_train <- model.matrix(~ ., data = df_train[, -ncol(df_train)])[ , -1]
y_train <- df_train$most_severe_injury

grid <- 10^seq(2, -4, length = 100)  # From 100 to 0.0001

lasso_model <- cv.glmnet(
  x = x_train,
  y = y_train,
  family = "multinomial",
  alpha = 1,
  lambda = grid,
  type.measure = "class", 
  nfolds = 10
)

plot(lasso_model)
lasso_model$lambda.min
coef(lasso_model, s = lasso_model$lambda.min)
lasso_train_accuracy <- 1 - lasso_model$cvm[lasso_model$lambda == lasso_model$lambda.min] #training error


# --- 3.3 --- Multinomial Log GAM
df_grid <- 4:10
k <- 10  # Number of folds

folds <- createFolds(df_train$most_severe_injury, k = k)

models <- list()
results <- data.frame(df = integer(), Fold = integer(), Accuracy = numeric())

# Loop over each df
for (df_i in df_grid) {
  cat("Tuning df =", df_i, "\n")
  
  for (i in seq_along(folds)) {
    cat("  Fold", i, "\n")
    
    val_idx <- folds[[i]]
    train_fold <- df_train[-val_idx, ]
    val_fold <- df_train[val_idx, ]
    
    # Fit the GAM model
    model <- vglm(
      most_severe_injury ~ 
        crash_hour + 
        s(crash_month, df = df_i) + 
        traffic_control_device + 
        lighting_condition + 
        weather_condition + 
        first_crash_type + 
        crash_day_of_week,
      family = multinomial(refLevel = "NO INDICATION OF INJURY"),
      data = train_fold
    )
    
    # Predict on validation fold
    probs <- predict(model, newdata = val_fold, type = "response")
    preds <- colnames(probs)[apply(probs, 1, which.max)]
    
    # Accuracy
    acc <- mean(preds == val_fold$most_severe_injury)
    
    # Save result
    results <- rbind(results, data.frame(df = df_i, Fold = i, Accuracy = acc))
  }
}

GAM_accuracy <- aggregate(Accuracy ~ df, data = results, FUN = mean)

final_gam <- vglm(
  most_severe_injury ~ 
    crash_hour + 
    s(crash_month, df = 4) + 
    traffic_control_device + 
    lighting_condition + 
    weather_condition + 
    first_crash_type + 
    crash_day_of_week,
  family = multinomial(refLevel = "NO INDICATION OF INJURY"),
  data = df_train
)
summary(final_gam)


# --- 3.4 --- Tree Model

tree_model <- rpart(
  most_severe_injury ~ .,
  data = df_train,
  method = "class",
  control = rpart.control(
    xval = 10,  
    minbucket = 2, 
    cp = 0        
  )
)

printcp(tree_model)     
plotcp(tree_model)      
best_cp<- tree_model$cptable[which.min(tree_model$cptable[,"xerror"]), "CP"]

tree_pruned <- prune(tree_model, cp = best_cp)

rpart.plot(tree_pruned, type = 2, extra = 104, cex = 0.7)
summary(tree_pruned)


# --- 3.5 --- Random Forest
ctrl <- trainControl(method = "oob")

mtry_grid <- expand.grid(mtry = 1:(ncol(df_train) - 1))  # exclude target

rf_model <- train(
  most_severe_injury ~ ., 
  data = df_train,
  method = "rf",
  trControl = ctrl,
  tuneGrid = mtry_grid,
  ntree = 500
)

print(rf_model)
varImp(rf_model)
plot(varImp(rf_model), top = 23)


# --- 3.6 --- SVM
svm_model <- svm(
  most_severe_injury ~ ., 
  data = df_train,
  type = "C-classification", 
  kernel = "radial",         # or "linear", "polynomial", etc.
  gamma = 1,
  cost = 0.2
)
summary(svm_model)
svm_pred <- predict(svm_model, df_train)
conf_mat <- confusionMatrix(svm_pred, df_train$most_severe_injury)
conf_mat$overall["Accuracy"]
conf_mat$byClass


# --- 4.0 --- Test 
get_class_metrics <- function(model_name, pred, truth) {
  cm <- confusionMatrix(pred, truth)
  acc <- as.numeric(cm$overall["Accuracy"])
  by_class <- as.data.frame(cm$byClass)
  
  # For binary classification, convert vector to one-row data frame
  if (is.null(dim(by_class))) {
    by_class <- as.data.frame(t(by_class))
    rownames(by_class) <- levels(truth)[2]
  }
  
  by_class$Model <- model_name
  by_class$Class <- rownames(by_class)
  by_class$Accuracy <- acc
  
  by_class %>%
    select(Model, Class, Accuracy, Sensitivity, Specificity, F1)
}

# --- Generate predictions and metrics for each model ---
accuracy_list <- list()
# KNN
pred_knn <- predict(knn_model, newdata = df_test)
knn_metrics <- get_class_metrics("KNN", pred_knn, df_test$most_severe_injury)
cm_knn <- confusionMatrix(pred_knn, df_test$most_severe_injury)
accuracy_list[["KNN"]] <- cm_knn$overall["Accuracy"]

# LASSO
x_test <- model.matrix(~ ., data = df_test[, -ncol(df_test)])[ , -1]
pred_lasso_prob <- predict(lasso_model, newx = x_test, s = lasso_model$lambda.min, type = "response")
pred_lasso <- colnames(pred_lasso_prob)[apply(pred_lasso_prob, 1, which.max)]
pred_lasso <- factor(pred_lasso, levels = levels(df_test$most_severe_injury))
lasso_metrics <- get_class_metrics("LASSO", pred_lasso, df_test$most_severe_injury)
cm_lasso <- confusionMatrix(pred_lasso, df_test$most_severe_injury)
accuracy_list[["LASSO"]] <- cm_lasso$overall["Accuracy"]

# GAM
pred_gam_prob <- predict(final_gam, newdata = df_test, type = "response")
pred_gam <- colnames(pred_gam_prob)[apply(pred_gam_prob, 1, which.max)]
pred_gam <- factor(pred_gam, levels = levels(df_test$most_severe_injury))
gam_metrics <- get_class_metrics("GAM", pred_gam, df_test$most_severe_injury)
cm_gam <- confusionMatrix(pred_gam, df_test$most_severe_injury)
accuracy_list[["GAM"]] <- cm_gam$overall["Accuracy"]


# Decision Tree
pred_tree <- predict(tree_pruned, newdata = df_test, type = "class")
tree_metrics <- get_class_metrics("Decision Tree", pred_tree, df_test$most_severe_injury)
cm_tree <- confusionMatrix(pred_tree, df_test$most_severe_injury)
accuracy_list[["Decision Tree"]] <- cm_tree$overall["Accuracy"]


# Random Forest
pred_rf <- predict(rf_model, newdata = df_test)
rf_metrics <- get_class_metrics("Random Forest", pred_rf, df_test$most_severe_injury)
cm_rf <- confusionMatrix(pred_rf, df_test$most_severe_injury)
accuracy_list[["Random Forest"]] <- cm_rf$overall["Accuracy"]

# SVM
pred_svm <- predict(svm_model, newdata = df_test)
svm_metrics <- get_class_metrics("SVM", pred_svm, df_test$most_severe_injury)
cm_svm <- confusionMatrix(pred_svm, df_test$most_severe_injury)
accuracy_list[["SVM"]] <- cm_svm$overall["Accuracy"]

# --- Combine all metrics into a single data frame ---
class_results <- bind_rows(
  knn_metrics, lasso_metrics, gam_metrics,
  tree_metrics, rf_metrics, svm_metrics
)

class_results <- round(class_results, 4)

# -- General Performance Metrics ---
accuracy_df <- data.frame(
  Model = names(accuracy_list),
  Accuracy = round(as.numeric(unlist(accuracy_list)), 4)
)


# --- Split and display by class ---
split_by_class <- split(class_results, class_results$Class)

for (class_name in names(split_by_class)) {
  cat("\n=== Metrics for Class:", class_name, "===\n")
  print(split_by_class[[class_name]])
}


# --- Fit to all data ---
x_all <- model.matrix(~ ., data = df_clean[, -ncol(df_clean)])[ , -1]


pred_probs <- predict(lasso_model, newx = x_all, s = lasso_model$lambda.min, type = "response")
pred_classes <- colnames(pred_probs)[apply(pred_probs, 1, which.max)]
pred_classes <- factor(pred_classes, levels = levels(df_clean$most_severe_injury))

conf_mat <- confusionMatrix(pred_classes, df_clean$most_severe_injury)


# --- vairables distribution checker ---
chisq.test(table(df_clean$crash_hour, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$crash_hour, df_clean$most_severe_injury),
           main = "Crash Hour", shade = TRUE, las = 2)

chisq.test(table(as.factor(df_clean$crash_month), df_clean$most_severe_injury))$stdres
mosaicplot(table(as.factor(df_clean$crash_month), df_clean$most_severe_injury),
           main = "Crash Month ", shade = TRUE, las = 2)

chisq.test(table(df_clean$crash_day_of_week, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$crash_day_of_week, df_clean$most_severe_injury),
           main = "Day of Week", shade = TRUE, las = 2)

chisq.test(table(df_clean$traffic_control_device, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$traffic_control_device, df_clean$most_severe_injury),
           main = "Traffic Control", shade = TRUE, las = 2)

chisq.test(table(df_clean$weather_condition, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$weather_condition, df_clean$most_severe_injury),
           main = "Weather", shade = TRUE, las = 2)

chisq.test(table(df_clean$lighting_condition, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$lighting_condition, df_clean$most_severe_injury),
           main = "Lighting", shade = TRUE, las = 2)

chisq.test(table(df_clean$first_crash_type, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$first_crash_type, df_clean$most_severe_injury),
           main = "Crash Type", shade = TRUE, las = 2)

chisq.test(table(df_clean$roadway_surface_cond, df_clean$most_severe_injury))$stdres
mosaicplot(table(df_clean$roadway_surface_cond, df_clean$most_severe_injury),
           main = "Surface Condition", shade = TRUE, las = 2)


